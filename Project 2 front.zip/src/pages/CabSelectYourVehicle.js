import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./CabSelectYourVehicle.module.css";
const CabSelectYourVehicle = () => {
  const navigate = useNavigate();

  const onEllipseImageClick = useCallback(() => {
    navigate("/login-sign-up-credentials");
  }, [navigate]);

  const onLogo4ImageClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  return (
    <div className={styles.cabSelectYourVehicle}>
      <div className={styles.illustration4}>
        <img className={styles.icon} alt="" src="/4@2x.png" />
        <div className={styles.illustration4Child} />
      </div>
      <img className={styles.iconsVertical} alt="" src="/icons-vertical3.svg" />
      <div className={styles.cab}>Cab</div>
      <img
        className={styles.cabSelectYourVehicleChild}
        alt=""
        onClick={onEllipseImageClick}
      />
      <div className={styles.cabSelectYourVehicleItem} />
      <div className={styles.selctedLocation}>
        <div className={styles.selctedLocationChild} />
        <div className={styles.yourSelectedSpot}>Your selected spot</div>
        <img className={styles.vectorIcon} alt="" src="/vector3.svg" />
      </div>
      <div className={styles.day}>
        <div className={styles.dayChild} />
        <img className={styles.vectorIcon1} alt="" src="/vector4.svg" />
        <div className={styles.day1}>Day</div>
      </div>
      <div className={styles.date}>
        <div className={styles.dateChild} />
        <div className={styles.date1}>Date</div>
      </div>
      <div className={styles.time}>Time</div>
      <div className={styles.ola}>
        <div className={styles.olaChild} />
        <img className={styles.olaItem} alt="" src="/rectangle-16@2x.png" />
        <a
          className={styles.httpswwwolacabscom}
          href="https://www.olacabs.com/"
          target="_blank"
        >
          https://www.olacabs.com/
        </a>
        <img className={styles.vectorIcon2} alt="" src="/vector5.svg" />
      </div>
      <div className={styles.uber}>
        <div className={styles.olaChild} />
        <img className={styles.olaItem} alt="" src="/rectangle-17@2x.png" />
        <img className={styles.vectorIcon2} alt="" src="/vector5.svg" />
        <a
          className={styles.httpswwwubercominen}
          href="https://www.uber.com/in/en/"
          target="_blank"
        >
          https://www.uber.com/in/en/
        </a>
      </div>
      <div className={styles.rapido}>
        <div className={styles.olaChild} />
        <img className={styles.olaItem} alt="" />
        <img className={styles.vectorIcon2} alt="" src="/vector5.svg" />
        <a
          className={styles.httpswwwrapidobike}
          href="https://www.rapido.bike/"
          target="_blank"
        >
          https://www.rapido.bike/
        </a>
      </div>
      <img className={styles.logo4Icon} alt="" onClick={onLogo4ImageClick} />
    </div>
  );
};

export default CabSelectYourVehicle;
