import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./ExploreSpotYourLocation.module.css";
const ExploreSpotYourLocation = () => {
  const navigate = useNavigate();

  const onEllipseImageClick = useCallback(() => {
    navigate("/login-sign-up-credentials");
  }, [navigate]);

  const onNearestSpotTextClick = useCallback(() => {
    navigate("/info-place-you-selected");
  }, [navigate]);

  const onLogo2ImageClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  return (
    <div className={styles.exploreSpotYourLocation}>
      <div className={styles.illustration2}>
        <img className={styles.icon} alt="" src="/2@2x.png" />
        <div className={styles.illustration2Child} />
      </div>
      <img className={styles.iconsVertical} alt="" src="/icons-vertical1.svg" />
      <div className={styles.explore}>Explore</div>
      <div className={styles.exploreSpotYourLocationChild} />
      <div className={styles.exploreSpotYourLocationItem} />
      <img
        className={styles.exploreSpotYourLocationInner}
        alt=""
        onClick={onEllipseImageClick}
      />
      <img className={styles.vectorIcon} alt="" src="/vector1.svg" />
      <img className={styles.vectorIcon1} alt="" src="/vector2.svg" />
      <div className={styles.yourLocation}>Your location</div>
      <div className={styles.nearestSpot} onClick={onNearestSpotTextClick}>
        Nearest spot
      </div>
      <div className={styles.rectangleDiv} />
      <div className={styles.exploreSpotYourLocationChild1} />
      <div className={styles.exploreSpotYourLocationChild2} />
      <div className={styles.exploreSpotYourLocationChild3} />
      <div className={styles.exploreSpotYourLocationChild4} />
      <div className={styles.exploreSpotYourLocationChild5} />
      <img className={styles.groupIcon} alt="" src="/group-2.svg" />
      <div className={styles.writeNearestPicnic}>Write nearest picnic spot</div>
      <div className={styles.writeNearestPark}>Write nearest park</div>
      <div className={styles.writeNearestPark1}>Write nearest park</div>
      <div className={styles.picnicSpotCum}>Picnic spot cum park</div>
      <div className={styles.picnicSpotCum1}>Picnic spot cum park</div>
      <div className={styles.writeNearestPicnic1}>
        Write nearest picnic spot
      </div>
      <div className={styles.kms}>1 kms</div>
      <div className={styles.kms1}>1.5 kms</div>
      <div className={styles.kms2}>2 kms</div>
      <img className={styles.logo2Icon} alt="" onClick={onLogo2ImageClick} />
    </div>
  );
};

export default ExploreSpotYourLocation;
