import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./HomePage.module.css";
const HomePage = () => {
  const navigate = useNavigate();

  const onVectorIconClick = useCallback(() => {
    navigate("/explore-spot-your-location");
  }, [navigate]);

  const onEllipseImageClick = useCallback(() => {
    navigate("/login-sign-up-credentials");
  }, [navigate]);

  return (
    <div className={styles.homePage}>
      <img
        className={styles.illustration1Icon}
        alt=""
        src="/illustration-1@2x.png"
      />
      <img className={styles.iconsVertical} alt="" src="/icons-vertical.svg" />
      <img
        className={styles.iconsHorizontal}
        alt=""
        src="/icons-horizontal.svg"
      />
      <div className={styles.travel}>Travel</div>
      <div className={styles.homePageChild} />
      <img
        className={styles.vectorIcon}
        alt=""
        src="/vector.svg"
        onClick={onVectorIconClick}
      />
      <div className={styles.searchForYour}>
        Search for your nearest picnic spot
      </div>
      <img
        className={styles.homePageItem}
        alt=""
        onClick={onEllipseImageClick}
      />
      <img className={styles.logo1Icon} alt="" />
    </div>
  );
};

export default HomePage;
