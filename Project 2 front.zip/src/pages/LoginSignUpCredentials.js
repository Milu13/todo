import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./LoginSignUpCredentials.module.css";
const LoginSignUpCredentials = () => {
  const navigate = useNavigate();

  const onLogo6ImageClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  return (
    <div className={styles.loginSignUpCredentials}>
      <img className={styles.iconsVertical} alt="" src="/icons-vertical5.svg" />
      <img className={styles.loginSignUpCredentialsChild} alt="" />
      <img className={styles.logo6Icon} alt="" onClick={onLogo6ImageClick} />
      <img className={styles.image3Icon} alt="" />
      <div className={styles.loginSignUpCredentialsItem} />
      <div className={styles.loginSignUpCredentialsInner} />
      <div className={styles.rectangleDiv} />
      <div className={styles.loginSignUpCredentialsChild1} />
      <a
        className={styles.loginWithGoogle}
        href="http://www.gmail.com"
        target="_blank"
      >
        Login with Google
      </a>
      <a
        className={styles.loginWithFacebook}
        href="https://www.facebook.com/"
        target="_blank"
      >
        Login with Facebook
      </a>
      <img className={styles.vectorIcon} alt="" src="/vector14.svg" />
      <img className={styles.vectorIcon1} alt="" src="/vector15.svg" />
      <div className={styles.lineDiv} />
      <div className={styles.loginSignUpCredentialsChild2} />
      <div className={styles.loginSignUpCredentialsChild3} />
      <div className={styles.loginSignUpCredentialsChild4} />
      <div className={styles.enterYourFull}>Enter your full name</div>
      <div className={styles.enterYourMail}>Enter your mail account</div>
      <div className={styles.createAnUser}>Create an user name</div>
      <div className={styles.enterAStrong}>Enter a strong password</div>
      <div className={styles.loginSignUpCredentialsChild5} />
      <div className={styles.login}>LOGIN</div>
    </div>
  );
};

export default LoginSignUpCredentials;
