import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import HomePage from "./pages/HomePage";
import ExploreSpotYourLocation from "./pages/ExploreSpotYourLocation";
import InfoPlaceYouSelected from "./pages/InfoPlaceYouSelected";
import CabSelectYourVehicle from "./pages/CabSelectYourVehicle";
import HotelsInnsSelectYourSt from "./pages/HotelsInnsSelectYourSt";
import RestaurantsSelectRestaura from "./pages/RestaurantsSelectRestaura";
import LoginSignUpCredentials from "./pages/LoginSignUpCredentials";
import { useEffect } from "react";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/explore-spot-your-location":
        title = "";
        metaDescription = "";
        break;
      case "/info-place-you-selected":
        title = "";
        metaDescription = "";
        break;
      case "/cab-select-your-vehicle":
        title = "";
        metaDescription = "";
        break;
      case "/hotels-inns-select-your-stay-location":
        title = "";
        metaDescription = "";
        break;
      case "/restaurants-select-restaurant":
        title = "";
        metaDescription = "";
        break;
      case "/login-sign-up-credentials":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route
        path="/explore-spot-your-location"
        element={<ExploreSpotYourLocation />}
      />
      <Route
        path="/info-place-you-selected"
        element={<InfoPlaceYouSelected />}
      />
      <Route
        path="/cab-select-your-vehicle"
        element={<CabSelectYourVehicle />}
      />
      <Route
        path="/hotels-inns-select-your-stay-location"
        element={<HotelsInnsSelectYourSt />}
      />
      <Route
        path="/restaurants-select-restaurant"
        element={<RestaurantsSelectRestaura />}
      />
      <Route
        path="/login-sign-up-credentials"
        element={<LoginSignUpCredentials />}
      />
    </Routes>
  );
}
export default App;
