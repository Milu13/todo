import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./InfoPlaceYouSelected.module.css";
const InfoPlaceYouSelected = () => {
  const navigate = useNavigate();

  const onEllipseImageClick = useCallback(() => {
    navigate("/login-sign-up-credentials");
  }, [navigate]);

  const onLogo3ImageClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  return (
    <div className={styles.infoPlaceYouSelected}>
      <div className={styles.illustration3}>
        <img className={styles.icon} alt="" src="/3@2x.png" />
        <div className={styles.illustration3Child} />
      </div>
      <img className={styles.iconsVertical} alt="" src="/icons-vertical2.svg" />
      <div className={styles.info}>Info</div>
      <div className={styles.infoPlaceYouSelectedChild} />
      <img
        className={styles.infoPlaceYouSelectedItem}
        alt=""
        onClick={onEllipseImageClick}
      />
      <div className={styles.yourSelectedSpot}>Your selected spot</div>
      <img className={styles.vectorIcon} alt="" src="/vector3.svg" />
      <div className={styles.image2Wrapper}>
        <img className={styles.image2Icon} alt="" />
      </div>
      <div className={styles.infoPlaceYouSelectedInner} />
      <div className={styles.about}>About</div>
      <div className={styles.location}>{`Location : `}</div>
      <div className={styles.entryFee}>{`Entry Fee : `}</div>
      <div className={styles.timings}>{`Timings : `}</div>
      <div className={styles.lineDiv} />
      <img className={styles.logo3Icon} alt="" onClick={onLogo3ImageClick} />
    </div>
  );
};

export default InfoPlaceYouSelected;
