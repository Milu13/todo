import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./HotelsInnsSelectYourSt.module.css";
const HotelsInnsSelectYourSt = () => {
  const navigate = useNavigate();

  const onEllipseImageClick = useCallback(() => {
    navigate("/login-sign-up-credentials");
  }, [navigate]);

  const onLogo5ImageClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  return (
    <div className={styles.hotelsInnsSelectYourSt}>
      <div className={styles.illustration5}>
        <img className={styles.icon} alt="" src="/5@2x.png" />
        <div className={styles.illustration5Child} />
      </div>
      <img className={styles.iconsVertical} alt="" src="/icons-vertical4.svg" />
      <div className={styles.hotels}>Hotels</div>
      <img
        className={styles.hotelsInnsSelectYourStChild}
        alt=""
        onClick={onEllipseImageClick}
      />
      <div className={styles.selctedLocation}>
        <div className={styles.selctedLocationChild} />
        <div className={styles.hotelsInns}>{`Hotels & Inns around `}</div>
        <img className={styles.vectorIcon} alt="" src="/vector6.svg" />
      </div>
      <div className={styles.oyo}>
        <div className={styles.oyoChild} />
        <img className={styles.oyoItem} alt="" />
        <a
          className={styles.httpswwwoyoroomscom}
          href="https://www.oyorooms.com/"
          target="_blank"
        >
          https://www.oyorooms.com/
        </a>
        <img className={styles.vectorIcon1} alt="" src="/vector7.svg" />
      </div>
      <div className={styles.airbnb}>
        <div className={styles.oyoChild} />
        <img className={styles.oyoItem} alt="" />
        <img className={styles.vectorIcon1} alt="" src="/vector8.svg" />
        <a
          className={styles.httpswwwairbnbcoin}
          href="https://www.airbnb.co.in/"
          target="_blank"
        >
          https://www.airbnb.co.in/
        </a>
      </div>
      <div className={styles.fab}>
        <div className={styles.oyoChild} />
        <img className={styles.oyoItem} alt="" src="/rectangle-20@2x.png" />
        <img className={styles.vectorIcon1} alt="" src="/vector9.svg" />
        <a
          className={styles.httpswwwfabhotelscom}
          href="https://www.fabhotels.com/"
          target="_blank"
        >
          https://www.fabhotels.com/
        </a>
      </div>
      <img className={styles.logo5Icon} alt="" onClick={onLogo5ImageClick} />
    </div>
  );
};

export default HotelsInnsSelectYourSt;
