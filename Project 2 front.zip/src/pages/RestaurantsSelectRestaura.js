import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./RestaurantsSelectRestaura.module.css";
const RestaurantsSelectRestaura = () => {
  const navigate = useNavigate();

  const onEllipseImageClick = useCallback(() => {
    navigate("/login-sign-up-credentials");
  }, [navigate]);

  const onLogo6ImageClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  return (
    <div className={styles.restaurantsSelectRestaura}>
      <div className={styles.illustration6}>
        <img className={styles.icon} alt="" src="/6@2x.png" />
        <div className={styles.illustration6Child} />
      </div>
      <img className={styles.iconsVertical} alt="" src="/icons-vertical4.svg" />
      <div className={styles.food}>Food</div>
      <img
        className={styles.restaurantsSelectRestauraChild}
        alt=""
        onClick={onEllipseImageClick}
      />
      <div className={styles.selctedLocation}>
        <div className={styles.selctedLocationChild} />
        <div className={styles.somethingToEat}>Something to eat</div>
      </div>
      <div className={styles.zomato}>
        <div className={styles.zomatoChild} />
        <img className={styles.zomatoItem} alt="" />
        <a
          className={styles.httpswwwzomatocom}
          href="https://www.zomato.com/"
          target="_blank"
        >
          https://www.zomato.com/
        </a>
        <img className={styles.vectorIcon} alt="" src="/vector10.svg" />
      </div>
      <div className={styles.swiggy}>
        <div className={styles.zomatoChild} />
        <img className={styles.zomatoItem} alt="" />
        <img className={styles.vectorIcon} alt="" src="/vector11.svg" />
        <a
          className={styles.httpswwwswiggycom}
          href="https://www.swiggy.com/"
          target="_blank"
        >
          https://www.swiggy.com/
        </a>
      </div>
      <div className={styles.doordash}>
        <div className={styles.zomatoChild} />
        <img className={styles.zomatoItem} alt="" src="/rectangle-201@2x.png" />
        <img className={styles.vectorIcon} alt="" src="/vector12.svg" />
        <a
          className={styles.httpswwwdoordashcom}
          href="https://www.doordash.com/"
          target="_blank"
        >
          https://www.doordash.com/
        </a>
      </div>
      <img className={styles.vectorIcon3} alt="" src="/vector13.svg" />
      <img className={styles.logo6Icon} alt="" onClick={onLogo6ImageClick} />
    </div>
  );
};

export default RestaurantsSelectRestaura;
